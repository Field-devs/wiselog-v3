import { UsersManagement } from "@/components/users-management"

export default function TeamsPage() {
  return (
    <div className="p-6">
      <UsersManagement />
    </div>
  )
}
